import socket
import json
import threading
import time
from common.packet_models import make_response_packet, make_user_list_packet, make_shutdown_packet
from common.db_manager.db_connection import DBConnection
from server.DAO.UserDAO import UserDAO
from server.DAO.MessageDAO import MessageDAO
from server.DAO.GroupDAO import GroupDAO
from server.DAO.GroupMemberDAO import GroupMemberDAO
from common.models.Group import Group
from common.models.GroupMember import GroupMember
from common.models.Message import Message

class SocketServer:
    def __init__(self, host='0.0.0.0', tcp_port=50005, udp_port=50006):
        self.host = host
        self.tcp_port = tcp_port
        self.udp_port = udp_port
        self.running = False
        
        # Veritabanı Hazırlığı
        import os
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        db_path = os.path.join(project_root, "data", "database.db")
        self.db_manager = DBConnection(db_path)
        
        # Sadece kullanıcıları tut, diğer her şeyi temizle (Kullanıcı isteği)
        self._clear_session_data()
        self._setup_tables()
        
        self.user_dao = UserDAO(self.db_manager)
        self.message_dao = MessageDAO(self.db_manager)
        self.group_dao = GroupDAO(self.db_manager)
        self.group_member_dao = GroupMemberDAO(self.db_manager)
        
        self.clients = {} # {username: socket}
        self.client_info = {} # {socket: username}
        self.lock = threading.Lock()

    def start(self):
        # 1. TCP Soketi Oluştur ve Bind Et (Single Server Check)
        try:
            self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_sock.bind((self.host, self.tcp_port))
            self.server_sock.listen(10)
            self.server_sock.settimeout(1.0)
            self.running = True
            print(f"[SERVER] TCP Sunucu {self.tcp_port} portunda başlatıldı.")
        except Exception as e:
            print(f"[SERVER] Başlatılamadı (Port kullanımda olabilir): {e}")
            return False

        # 2. UDP Discovery Thread'i Başlat
        self.udp_thread = threading.Thread(target=self._udp_broadcast, daemon=True)
        self.udp_thread.start()

        # 3. Ana Kabul Döngüsü
        self.accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.accept_thread.start()
        
        return True

    def _udp_broadcast(self):
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        
        msg = json.dumps({"type": "server_discovery", "port": self.tcp_port}).encode('utf-8')
        
        while self.running:
            try:
                # 1. Genel Broadcast
                for addr in ['<broadcast>', '255.255.255.255']:
                    try: udp_sock.sendto(msg, (addr, self.udp_port))
                    except: pass
                
                # 2. Yerel Ağ Arayüzlerini Tara ve Her Birine Gönder
                try:
                    hostname = socket.gethostname()
                    ips = socket.gethostbyname_ex(hostname)[2]
                    for ip in ips:
                        # 192.168.1.x -> 192.168.1.255
                        broadcast_ip = ".".join(ip.split(".")[:-1]) + ".255"
                        try: udp_sock.sendto(msg, (broadcast_ip, self.udp_port))
                        except: pass
                except: pass
                
                time.sleep(3) 
            except Exception as e:
                print(f"[SERVER] UDP Broadcast Hatası: {e}")
                break
        udp_sock.close()

    def _accept_loop(self):
        while self.running:
            try:
                client_sock, addr = self.server_sock.accept()
                print(f"[SERVER] Yeni bağlantı: {addr}")
                threading.Thread(target=self._handle_client, args=(client_sock, addr), daemon=True).start()
            except socket.timeout:
                continue
            except:
                break

    def _clear_session_data(self):
        """Uygulama başladığında grupları ve mesajları temizle."""
        try:
            self.db_manager.execute("DROP TABLE IF EXISTS Messages")
            self.db_manager.execute("DROP TABLE IF EXISTS Groups")
            self.db_manager.execute("DROP TABLE IF EXISTS Group_Members")
            print("[SERVER] Oturum verileri (mesajlar ve gruplar) temizlendi.")
        except Exception as e:
            print(f"[SERVER] Temizlik hatası: {e}")

    def _setup_tables(self):
        """Tabloları hazırla. Users tablosu korunur, diğerleri her seferinde yeniden oluşturulur."""
        # Users (Persistent)
        self.db_manager.execute("""
            CREATE TABLE IF NOT EXISTS Users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password_hash TEXT,
                first_name TEXT,
                last_name TEXT,
                avatar TEXT,
                bg_color TEXT,
                lastseen TEXT
            )
        """)
        # Messages (Session-based, recreated)
        self.db_manager.execute("""
            CREATE TABLE IF NOT EXISTS Messages (
                message_id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender TEXT,
                receiver TEXT,
                group_id INTEGER,
                message_type TEXT,
                content TEXT,
                file_path TEXT,
                msg_id TEXT UNIQUE,
                timestamp TEXT,
                reply_to_id TEXT,
                is_forwarded INTEGER DEFAULT 0,
                is_edited INTEGER DEFAULT 0
            )
        """)
        # Groups (Session-based, recreated)
        self.db_manager.execute("""
            CREATE TABLE IF NOT EXISTS Groups (
                group_id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_name TEXT,
                created_by TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Group Members (Session-based, recreated)
        self.db_manager.execute("""
            CREATE TABLE IF NOT EXISTS Group_Members (
                group_id INTEGER,
                username TEXT,
                is_admin INTEGER DEFAULT 0,
                PRIMARY KEY (group_id, username)
            )
        """)
        # Blocked Users (Persistent)
        self.db_manager.execute("""
            CREATE TABLE IF NOT EXISTS BlockedUsers (
                blocker TEXT,
                blocked TEXT,
                PRIMARY KEY (blocker, blocked)
            )
        """)

    def _handle_client(self, sock, addr):
        self._setup_tables()
        import codecs
        decoder = codecs.getincrementaldecoder('utf-8')(errors='ignore')
        buffer = ""
        while self.running:
            try:
                raw_data = sock.recv(65536)
                if not raw_data:
                    break
                
                buffer += decoder.decode(raw_data)
                while True:
                    buffer = buffer.lstrip()
                    if not buffer: break
                    try:
                        packet, index = json.JSONDecoder().raw_decode(buffer)
                        buffer = buffer[index:].lstrip()
                        self._process_packet(sock, packet)
                    except json.JSONDecodeError:
                        break
                    except Exception as e:
                        print(f"[SERVER] Paket işleme hatası: {e}")
                        break
            except Exception as e:
                print(f"[SERVER] Bağlantı hatası ({addr}): {e}")
                break
        
        self._remove_client(sock)

    def _process_packet(self, sock, packet):
        action = packet.get("action")
        payload = packet.get("payload")
        print(f"[SERVER] Paket Alındı: {action}")

        if action == "LOGIN":
            username = payload.get("username")
            password = payload.get("password_hash")
            user = self.user_dao.validate_login(username, password)
            
            if user:
                with self.lock:
                    self.clients[username] = sock
                    self.client_info[sock] = username
                
                resp = make_response_packet("SUCCESS", "Giriş başarılı", user.__dict__)
                sock.sendall(json.dumps(resp).encode('utf-8'))
                self._broadcast_user_list()
                self._broadcast_group_list(username, sock)
            else:
                resp = make_response_packet("ERROR", "Hatalı kullanıcı adı veya şifre")
                sock.sendall(json.dumps(resp).encode('utf-8'))

        elif action == "REGISTER":
            from common.models.User import User
            new_user = User(username=payload.get("username"), passwordhash=payload.get("passwordhash"))
            success = self.user_dao.register_user(new_user)
            if success:
                resp = make_response_packet("SUCCESS", "Kayıt başarılı")
            else:
                resp = make_response_packet("ERROR", "Kullanıcı zaten mevcut")
            sock.sendall(json.dumps(resp).encode('utf-8'))

        elif action == "UPDATE_AVATAR":
            new_avatar = payload.get("avatar")
            username = self.client_info.get(sock)
            if username:
                # DB Güncelle
                self.db_manager.execute("UPDATE Users SET avatar = ? WHERE username = ?", (new_avatar, username))
                print(f"[SERVER] {username} profil fotoğrafını güncelledi.")
                self._broadcast_user_list()

        elif action == "SEND_MSG":
            sender = self.client_info.get(sock)
            if not sender: return
            
            # Payload'a göndereni ekle
            payload["sender"] = sender
            
            # Üyelik Kontrolü (Grup mesajı ise)
            gid = payload.get("group_id")
            if gid and not self.group_member_dao.is_user_in_group(gid, sender):
                print(f"[SERVER] Engel: {sender} artık grup {gid} üyesi değil.")
                return

            # Mesajı hedefe yönlendir
            with self.lock:
                if payload.get("group_id"):
                    # Grup mesajı: Tüm üyelere gönder (kendisi hariç)
                    members = self.group_member_dao.get_group_members(payload.get("group_id"))
                    for member in members:
                        if member.username != sender:
                            target_sock = self.clients.get(member.username)
                            if target_sock:
                                try: target_sock.sendall(json.dumps({"action": "RECEIVE_MSG", "payload": payload}).encode('utf-8'))
                                except: pass
                else:
                    # Özel mesaj
                    target = payload.get("target_ip")
                    target_sock = self.clients.get(target)
                    if target_sock:
                        try: target_sock.sendall(json.dumps({"action": "RECEIVE_MSG", "payload": payload}).encode('utf-8'))
                        except: pass
            
            # Mesajı veritabanına kaydet (In-Memory)
            from common.models.Message import Message
            msg_obj = Message.from_dict(payload)
            msg_obj.sender = sender
            # receiver set et (özel mesajsa)
            if not payload.get("group_id"):
                msg_obj.receiver = payload.get("target_ip")
            self.message_dao.save_message(msg_obj)
            
            # Gönderene "Sunucuya ulaştı" onayı
            resp = {
                "action": "RECEIPT",
                "payload": {"msg_id": payload.get("msg_id"), "status": "server_received", "target": payload.get("target_ip") or f"group_{payload.get('group_id')}"}
            }
            sock.sendall(json.dumps(resp).encode('utf-8'))

        elif action == "RECEIPT":
            target = payload.get("target")
            print(f"[SERVER] {action} aktarılıyor: {payload.get('status')} -> {target}")
            with self.lock:
                target_sock = self.clients.get(target)
                if target_sock:
                    try:
                        target_sock.sendall(json.dumps(packet).encode('utf-8'))
                    except: pass

        elif action == "BLOCK_USER":
            blocked_user = payload.get("blocked_username")
            blocker = self.client_info.get(sock)
            if blocker and blocked_user:
                self.db_manager.execute("INSERT OR IGNORE INTO BlockedUsers (blocker, blocked) VALUES (?, ?)", (blocker, blocked_user))
                print(f"[SERVER] {blocker}, {blocked_user} kullanıcısını engelledi.")
        
        elif action == "UNBLOCK_USER":
            blocked_user = payload.get("blocked_username")
            blocker = self.client_info.get(sock)
            if blocker and blocked_user:
                self.db_manager.execute("DELETE FROM BlockedUsers WHERE blocker = ? AND blocked = ?", (blocker, blocked_user))
                print(f"[SERVER] {blocker}, {blocked_user} engelini kaldırdı.")

        elif action == "DELETE_MSG":
            msg_id = payload.get("msg_id")
            target = payload.get("target")
            self.message_dao.delete_message(msg_id)
            # Hedefe/Gruba da silme bilgisini uçur
            self._notify_message_update("DELETE_MSG", {"msg_id": msg_id}, target)

        elif action == "EDIT_MSG":
            msg_id = payload.get("msg_id")
            new_content = payload.get("content")
            target = payload.get("target")
            self.message_dao.update_message_content(msg_id, new_content)
            self._notify_message_update("EDIT_MSG", {"msg_id": msg_id, "content": new_content}, target)

        elif action == "CREATE_GROUP":
            group_data = payload.get("group")
            members = payload.get("members") # List of usernames
            sender = self.client_info.get(sock)
            
            from common.models.Group import Group
            from common.models.GroupMember import GroupMember
            
            new_group = Group(group_name=group_data.get("group_name"), created_by=sender)
            self.group_dao.create_group(new_group)
            
            # Son eklenen grubun ID'sini al
            res = self.db_manager.fetch_one("SELECT MAX(group_id) as last_id FROM Groups")
            group_id = res['last_id']
            
            # Üyeleri ekle
            all_members = list(set(members + [sender]))
            for m in all_members:
                is_admin = 1 if m == sender else 0
                self.group_member_dao.add_member(GroupMember(group_id=group_id, username=m, is_admin=is_admin))
            
            # Üyelere bildir
            for m in all_members:
                m_sock = self.clients.get(m)
                if m_sock:
                    self._broadcast_group_list(m, m_sock)

        elif action == "ADD_GROUP_MEMBER":
            group_id = payload.get("group_id")
            username = payload.get("username")
            self.group_member_dao.add_member(GroupMember(group_id=group_id, username=username, is_admin=0))
            # Tüm üyelere grubun güncel halini bildir
            self._broadcast_group_info_to_members(group_id)

        elif action == "REMOVE_GROUP_MEMBER":
            group_id = payload.get("group_id")
            username = payload.get("username")
            # Önce üyeleri al ki bildirim yapabilelim (silmeden önce)
            all_members = self.group_member_dao.get_group_members(group_id)
            self.group_member_dao.remove_member(group_id, username)
            
            # Çıkarılan kişiye güncelleme gönder (boş liste/grup silinmiş gibi görünecek)
            m_sock = self.clients.get(username)
            if m_sock: self._broadcast_group_list(username, m_sock)
            
            # Kalan üyelere bildir
            for m in all_members:
                if m.username != username:
                    m_sock = self.clients.get(m.username)
                    if m_sock: self._broadcast_group_list(m.username, m_sock)

        elif action == "MAKE_ADMIN":
            group_id = payload.get("group_id")
            username = payload.get("username")
            self.group_member_dao.update_admin_status(group_id, username, 1)
            # Bilgi verilebilir
            self._broadcast_group_info_to_members(group_id)

        elif action == "DELETE_GROUP":
            group_id = payload.get("group_id")
            sender = self.client_info.get(sock)
            if self.group_member_dao.is_user_admin(group_id, sender):
                members = self.group_member_dao.get_group_members(group_id)
                # Üyelikleri de temizle
                self.db_manager.execute("DELETE FROM Group_Members WHERE group_id = ?", (group_id,))
                self.group_dao.delete_group(group_id)
                # Üyelere grubun silindiğini bildir
                for m in members:
                    m_sock = self.clients.get(m.username)
                    if m_sock:
                        self._broadcast_group_list(m.username, m_sock)

        elif action == "GET_HISTORY":
            target = payload.get("target") # Username or group_123
            sender = self.client_info.get(sock)
            if not sender: return
            
            if target.startswith("group_"):
                group_id = int(target.split("_")[1])
                history = self.message_dao.get_group_chat_history(group_id)
            else:
                history = self.message_dao.get_private_chat_history(sender, target)
            
            resp = {
                "action": "HISTORY_RES",
                "payload": {"target": target, "messages": [m.__dict__ for m in history]}
            }
            sock.sendall(json.dumps(resp).encode('utf-8'))

    def _broadcast_user_list(self):
        """Tüm kullanıcılara mevcut kullanıcı listesini (online/offline ve lastseen dahil) gönderir."""
        all_users = self.user_dao.get_all_users_info()
        online_users = list(self.clients.keys())
        
        user_list_payload = []
        for user in all_users:
            u_dict = dict(user)
            u_dict['is_online'] = u_dict['username'] in online_users
            user_list_payload.append(u_dict)

        packet = {"action": "USER_LIST_UPDATE", "payload": user_list_payload}
        data = json.dumps(packet).encode('utf-8')
        
        with self.lock:
            for sock in self.clients.values():
                try:
                    sock.sendall(data)
                except:
                    pass

    def _broadcast_group_list(self, username, sock):
        """Kullanıcının üye olduğu grupları gönderir."""
        group_ids = self.group_member_dao.get_user_groups(username)
        groups = []
        for gid in group_ids:
            g = self.group_dao.get_group_by_id(gid)
            if g:
                # Üyeleri de ekleyelim (Online durumlarıyla beraber)
                members = self.group_member_dao.get_group_members(gid)
                g_dict = g.__dict__
                m_list = []
                for m in members:
                    m_dict = m.__dict__
                    m_dict['is_online'] = m.username in self.clients
                    m_list.append(m_dict)
                g_dict['members'] = m_list
                groups.append(g_dict)
        
        packet = {"action": "GROUP_LIST_UPDATE", "payload": groups}
        try: sock.sendall(json.dumps(packet).encode('utf-8'))
        except: pass

    def _broadcast_group_info_to_members(self, group_id):
        """Grubun güncel halini tüm üyelere gönderir."""
        members = self.group_member_dao.get_group_members(group_id)
        for m in members:
            m_sock = self.clients.get(m.username)
            if m_sock:
                self._broadcast_group_list(m.username, m_sock)

    def _notify_message_update(self, action, payload, target):
        """Silme veya düzenleme bilgisini hedefe/gruba iletir."""
        with self.lock:
            if target.startswith("group_"):
                group_id = int(target.split("_")[1])
                members = self.group_member_dao.get_group_members(group_id)
                for m in members:
                    m_sock = self.clients.get(m.username)
                    if m_sock:
                        try: m_sock.sendall(json.dumps({"action": action, "payload": payload}).encode('utf-8'))
                        except: pass
            else:
                t_sock = self.clients.get(target)
                if t_sock:
                    try: t_sock.sendall(json.dumps({"action": action, "payload": payload}).encode('utf-8'))
                    except: pass

    def _remove_client(self, sock):
        with self.lock:
            username = self.client_info.pop(sock, None)
            if username:
                self.clients.pop(username, None)
                # Son görülme tarihini güncelle
                from datetime import datetime
                self.user_dao.update_lastseen(username, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                print(f"[SERVER] {username} ayrıldı.")
        self._broadcast_user_list()
        sock.close()

    def stop(self):
        self.running = False
        # Kapatma sinyali gönder
        packet = make_shutdown_packet()
        data = json.dumps(packet).encode('utf-8')
        
        with self.lock:
            for sock in self.clients.values():
                try:
                    sock.sendall(data)
                    sock.close()
                except: pass
            self.clients.clear()
            self.client_info.clear()
        
        try:
            self.server_sock.close()
        except: pass
