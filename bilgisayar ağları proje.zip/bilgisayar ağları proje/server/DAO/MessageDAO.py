# server/database/message_dao.py
from common.models.Message import Message

class MessageDAO:
    def __init__(self, db_manager):
        self.db = db_manager

    def save_message(self, msg_obj: Message):
        """
        Mesajı kaydeder.
        """
        query = """
            INSERT INTO Messages (sender, receiver, group_id, message_type, content, file_path, msg_id, timestamp, reply_to_id, is_forwarded, is_edited) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        params = (
            msg_obj.sender, 
            msg_obj.receiver, 
            msg_obj.group_id, 
            msg_obj.message_type, 
            msg_obj.content,
            msg_obj.file_path,
            msg_obj.msg_id,
            msg_obj.timestamp,
            getattr(msg_obj, 'reply_to_id', None),
            getattr(msg_obj, 'is_forwarded', 0),
            getattr(msg_obj, 'is_edited', 0)
        )
        try:
            return self.db.execute(query, params)
        except Exception as e:
            print(f"Mesaj kaydetme hatası: {e}")
            return False

    def update_message_content(self, msg_id, new_content):
        """Mesaj içeriğini günceller ve is_edited bayrağını set eder."""
        query = "UPDATE Messages SET content = ?, is_edited = 1 WHERE msg_id = ?"
        return self.db.execute(query, (new_content, msg_id))

    def get_message_by_msg_id(self, msg_id):
        """UUID (msg_id) üzerinden mesaj getirir."""
        query = "SELECT * FROM Messages WHERE msg_id = ?"
        row = self.db.fetch_one(query, (msg_id,))
        return Message.from_dict(row) if row else None

    def get_private_chat_history(self, user1, user2):
        """İki kullanıcı arasındaki özel mesaj geçmişini (DM) getirir."""
        query = """
            SELECT * FROM Messages 
            WHERE (sender = ? AND receiver = ? AND group_id IS NULL) 
               OR (sender = ? AND receiver = ? AND group_id IS NULL)
            ORDER BY timestamp ASC
        """
        rows = self.db.fetch_all(query, (user1, user2, user2, user1))
        return [Message.from_dict(row) for row in rows]

    def get_group_chat_history(self, group_id):
        """Bir gruba ait tüm mesajları getirir."""
        query = """
            SELECT * FROM Messages 
            WHERE group_id = ? 
            ORDER BY timestamp ASC
        """
        rows = self.db.fetch_all(query, (group_id,))
        return [Message.from_dict(row) for row in rows]

    def delete_message(self, msg_id):
        """msg_id (UUID) üzerinden mesaj siler."""
        query = "DELETE FROM Messages WHERE msg_id = ?"
        return self.db.execute(query, (msg_id,))

    def get_messages_paginated(self, username, offset=0, limit=50):
        query = """
            SELECT * FROM Messages 
            WHERE sender = ? OR receiver = ? OR group_id IN (
                SELECT group_id FROM Group_Members WHERE username = ?
            )
            ORDER BY timestamp DESC 
            LIMIT ? OFFSET ?
        """
        rows = self.db.fetch_all(query, (username, username, username, limit, offset))
        return [Message.from_dict(row) for row in rows]