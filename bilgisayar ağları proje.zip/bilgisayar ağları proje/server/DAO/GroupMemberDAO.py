# server/database/group_member_dao.py
from common.models.GroupMember import GroupMember

class GroupMemberDAO:
    def __init__(self, db_manager):
        self.db = db_manager

    def add_member(self, member_obj: GroupMember):
        """Gruba yeni bir üye ekler."""
        query = """
            INSERT INTO Group_Members (group_id, username, is_admin) 
            VALUES (?, ?, ?)
        """
        # Casting kaldırıldı, direkt modeldeki değeri (0/1) veriyoruz
        params = (member_obj.group_id, member_obj.username, member_obj.is_admin)
        try:
            return self.db.execute(query, params)
        except Exception as e:
            print(f"Üye ekleme hatası: {e}")
            return False

    def remove_member(self, group_id, username):
        """Üyeyi gruptan çıkarır."""
        query = "DELETE FROM Group_Members WHERE group_id = ? AND username = ? COLLATE NOCASE"
        return self.db.execute(query, (group_id, username))

    def get_group_members(self, group_id):
        """Belirli bir grubun tüm üyelerini nesne listesi olarak döner."""
        query = "SELECT * FROM Group_Members WHERE group_id = ?"
        rows = self.db.fetch_all(query, (group_id,))
        return [GroupMember.from_dict(row) for row in rows]

    def get_user_groups(self, username):
        """Kullanıcının dahil olduğu tüm grupların ID listesini döner."""
        query = "SELECT group_id FROM Group_Members WHERE username = ? COLLATE NOCASE"
        rows = self.db.fetch_all(query, (username,))
        return [row['group_id'] for row in rows]

    def update_admin_status(self, group_id, username, status):
        """Üyenin adminlik durumunu günceller (status: 0 veya 1)."""
        query = "UPDATE Group_Members SET is_admin = ? WHERE group_id = ? AND username = ? COLLATE NOCASE"
        return self.db.execute(query, (status, group_id, username))

    def is_user_admin(self, group_id, username):
        """Kullanıcının admin olup olmadığını döner (0 veya 1)."""
        query = "SELECT is_admin FROM Group_Members WHERE group_id = ? AND username = ? COLLATE NOCASE"
        row = self.db.fetch_one(query, (group_id, username))
        # bool() dönüşümü kaldırıldı, direkt DB'deki int değeri dönüyor
        return row['is_admin'] if row else 0

    def get_member_count(self, group_id):
        """Gruptaki toplam üye sayısını döner."""
        query = "SELECT COUNT(*) as count FROM Group_Members WHERE group_id = ?"
        row = self.db.fetch_one(query, (group_id,))
        return row['count'] if row else 0

    def is_member(self, group_id, username):
        """Kullanıcının grubun üyesi olup olmadığını kontrol eder (1: Evet, 0: Hayır)."""
        query = "SELECT 1 FROM Group_Members WHERE group_id = ? AND username = ? COLLATE NOCASE"
        row = self.db.fetch_one(query, (group_id, username))
        return 1 if row else 0