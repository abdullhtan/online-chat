from common.models.User import User 

class UserDAO:
    def __init__(self, db_manager):
        self.db = db_manager
        self._ensure_avatar_column()

    def _ensure_avatar_column(self):
        """Users tablosunda avatar kolonu yoksa ekler."""
        try:
            self.db.execute("ALTER TABLE Users ADD COLUMN avatar TEXT DEFAULT '👤'")
        except:
            pass # Zaten varsa hata verir, görmezden gel

    def register_user(self, user_obj: User):
        """
        user_id'yi SQLite otomatik atayacağı için query'den çıkardık.
        """
        query = """
            INSERT INTO Users (username, passwordhash, lastseen, avatar) 
            VALUES (?, ?, ?, ?)
        """
        # Sadece username, passwordhash, lastseen ve avatar gönderiyoruz
        params = (user_obj.username, user_obj.passwordhash, user_obj.lastseen, user_obj.avatar)
        try:
            self.db.execute(query, params)
            return True
        except Exception as e:
            print(f"Kayıt başarısız (Kullanıcı adı çakışması veya DB hatası): {e}")
            return False

    def validate_login(self, username, passwordhash):
        """Kullanıcıyı doğrular ve User nesnesi döner."""
        query = "SELECT * FROM Users WHERE username = ? AND passwordhash = ?"
        row = self.db.fetch_one(query, (username, passwordhash))
        return User.from_dict(row) if row else None

    def delete_user(self, user_id):
        """Kullanıcıyı ID üzerinden sistemden tamamen siler."""
        query = "DELETE FROM Users WHERE user_id = ?"
        try:
            self.db.execute(query, (user_id,))
            return True
        except Exception as e:
            print(f"Silme işlemi başarısız: {e}")
            return False

    def update_lastseen(self, username, time_str):
        query = "UPDATE Users SET lastseen = ? WHERE username = ? COLLATE NOCASE"
        return self.db.execute(query, (time_str, username))

    def get_all_users_info(self):
        """Tüm kullanıcıların temel bilgilerini (username, avatar, lastseen) döner."""
        query = "SELECT username, avatar, lastseen FROM Users"
        rows = self.db.fetch_all(query)
        return rows

    def get_user_by_username(self, username):
        query = "SELECT * FROM Users WHERE username = ? COLLATE NOCASE"
        row = self.db.fetch_one(query, (username,))
        return User.from_dict(row) if row else None

    def get_user_by_id(self, user_id):
        query = "SELECT * FROM Users WHERE user_id = ?"
        row = self.db.fetch_one(query, (user_id,))
        return User.from_dict(row) if row else None