# server/database/group_dao.py
from common.models.Group import Group

class GroupDAO:
    def __init__(self, db_manager):
        self.db = db_manager

    def create_group(self, group_obj: Group):
        """
        Yeni bir grup oluşturur. group_id AUTOINCREMENT olduğu için eklenmedi.
        """
        query = """
            INSERT INTO Groups (group_name, created_by, created_at) 
            VALUES (?, ?, ?)
        """
        params = (group_obj.group_name, group_obj.created_by, group_obj.created_at)
        try:
            # execute_query'nin başarılı olması durumunda True dönecektir
            return self.db.execute(query, params)
        except Exception as e:
            print(f"Grup oluşturma hatası: {e}")
            return False

    def get_group_by_id(self, group_id):
        """ID üzerinden grup bilgilerini getirir."""
        query = "SELECT * FROM Groups WHERE group_id = ?"
        row = self.db.fetch_one(query, (group_id,))
        return Group.from_dict(row) if row else None

    def get_groups_by_creator(self, username):
        """Belirli bir kullanıcının kurduğu grupları listeler."""
        query = "SELECT * FROM Groups WHERE created_by = ? COLLATE NOCASE"
        rows = self.db.fetch_all(query, (username,))
        return [Group.from_dict(row) for row in rows]

    def delete_group(self, group_id):
        """Grubu sistemden tamamen siler."""
        query = "DELETE FROM Groups WHERE group_id = ?"
        try:
            return self.db.execute(query, (group_id,))
        except Exception as e:
            print(f"Grup silme hatası: {e}")
            return False

    def update_group_name(self, group_id, new_name):
        """Grup adını günceller."""
        query = "UPDATE Groups SET group_name = ? WHERE group_id = ?"
        return self.db.execute(query, (new_name, group_id))