# server/database/block_dao.py
from common.models.Block import Block

class BlockDAO:
    def __init__(self, db_manager):
        self.db = db_manager

    def block_user(self, block_obj: Block):
        """Kullanıcıyı engellenenler listesine ekler."""
        query = "INSERT INTO Blocks (blocker, blocked) VALUES (?, ?)"
        params = (block_obj.blocker, block_obj.blocked)
        try:
            return self.db.execute_query(query, params)
        except Exception as e:
            print(f"Engelleme başarısız: {e}")
            return False

    def unblock_user(self, blocker, blocked):
        """Engeli kaldırır."""
        query = "DELETE FROM Blocks WHERE blocker = ? AND blocked = ? COLLATE NOCASE"
        return self.db.execute_query(query, (blocker, blocked))

    def is_blocked(self, blocker, blocked):
        """
        Kritik Metod: 'blocker' kişisi 'blocked' kişisini engellemiş mi?
        Mesaj iletilmeden önce Sunucu Servisi tarafından çağrılır.
        1 dönerse mesaj engellenir, 0 dönerse iletilir.
        """
        query = "SELECT 1 FROM Blocks WHERE blocker = ? AND blocked = ? COLLATE NOCASE"
        row = self.db.fetch_one(query, (blocker, blocked))
        return 1 if row else 0

    def get_my_blocked_list(self, username):
        """Kullanıcının kendi engellediği kişileri görmesi için (Ayarlar menüsü)."""
        query = "SELECT blocked FROM Blocks WHERE blocker = ? COLLATE NOCASE"
        rows = self.db.fetch_all(query, (username,))
        return [row['blocked'] for row in rows]