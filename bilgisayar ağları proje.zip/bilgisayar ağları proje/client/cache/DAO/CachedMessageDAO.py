# client/cache/cached_message_dao.py
from client.models.CachedMessage import CachedMessage

class CachedMessageDAO:
    def __init__(self, db_conn):
        self.db = db_conn

    # CREATE
    def save(self, msg: CachedMessage):
        query = """INSERT OR REPLACE INTO CachedMessages 
                   (message_id, sender, receiver, group_id, messages_type, content, 
                    timestamp, is_me, local_path, is_read) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        self.db.execute(query, (
            msg.message_id, msg.sender, msg.receiver, msg.group_id,
            msg.message_type, msg.content, msg.timestamp, msg.is_me,
            msg.local_path, msg.is_read
        ))

    # READ - Sohbet Listesi Sıralama 
    def get_recent_chats(self):
        query = """
            SELECT *, MAX(timestamp) as last_msg_time 
            FROM CachedMessages 
            GROUP BY COALESCE(group_id, CASE WHEN is_me = 1 THEN receiver ELSE sender END)
            ORDER BY last_msg_time DESC
        """
        rows = self.db.fetch_all(query)
        return [CachedMessage.from_row(row) for row in rows]

    # READ - Spesifik Mesajlaşma Geçmişi
    def get_chat_history(self, chat_partner, limit=50):
        query = """SELECT * FROM CachedMessages 
                   WHERE (sender = ? OR receiver = ?) AND group_id IS NULL 
                   ORDER BY timestamp ASC LIMIT ?"""
        rows = self.db.fetch_all(query, (chat_partner, chat_partner, limit))
        return [CachedMessage.from_row(row) for row in rows]

    def get_group_history(self, group_id, limit=50):
        query = "SELECT * FROM CachedMessages WHERE group_id = ? ORDER BY timestamp ASC LIMIT ?"
        rows = self.db.fetch_all(query, (group_id, limit))
        return [CachedMessage.from_row(row) for row in rows]

    # UPDATE
    def mark_as_read(self, message_id):
        query = "UPDATE CachedMessages SET is_read = 1 WHERE message_id = ?"
        self.db.execute(query, (message_id,))

    # DELETE
    def delete_chat(self, chat_partner=None, group_id=None):
        if group_id:
            query = "DELETE FROM CachedMessages WHERE group_id = ?"
            self.db.execute(query, (group_id,))
        else:
            query = "DELETE FROM CachedMessages WHERE (sender = ? OR receiver = ?) AND group_id IS NULL"
            self.db.execute(query, (chat_partner, chat_partner))