from common.models import Group

class CachedGroup(Group):
    def __init__(self, group_id, group_name, created_by, created_at, is_admin=0):
        super().__init__(group_id, group_name, created_by, created_at)
        self.is_admin = is_admin

    @classmethod
    def from_row(cls, row):
        if not row: return None
        return cls(
            group_id=row['group_id'],
            group_name=row['group_name'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            is_admin=row['is_admin']
        )

    def to_dict(self):
        data = {
            "group_id": self.group_id,
            "group_name": self.group_name,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "is_admin": self.is_admin
        }
        return data

    def __repr__(self):
        return (f"<CachedGroup(ID={self.group_id}, Name='{self.group_name}', "
                f"IsAdmin={bool(self.is_admin)})>")