# client/models/cache_models.py
from common.models import User

class CachedUser(User):
    def __init__(self, username, last_seen):
        # Üst sınıfa ortak verileri paslıyoruz
        super().__init__(username, last_seen)
        # Yerel ekstralar varsa buraya eklenebilir (örn: self.is_friend = True)

    @classmethod
    def from_row(cls, row):
        """SQLite satırından (Row) nesne üretir."""
        if not row: return None
        return cls(
            username=row['username'],
            last_seen=row['last_seen']
        )

    def to_dict(self):
        """Nesneyi sözlük formatına çevirir (Ağ paketleri veya JSON için)."""
        return {
            "username": self.username,
            "last_seen": self.last_seen
        }

    def __repr__(self):
        """Geliştirici dostu çıktı (Debug için)."""
        return f"<CachedUser(username='{self.username}', last_seen='{self.last_seen}')>"