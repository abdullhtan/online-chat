import socket
import json
import threading
import time
from PyQt6.QtCore import QObject, pyqtSignal

class LANService(QObject):
    """Merkezi Sunucuya Bağlanan İstemci Servisi"""
    peer_found = pyqtSignal(dict) # { 'ip': '...', 'username': '...', 'first_name': '...', 'avatar': '👤' }
    message_received = pyqtSignal(str, str, str, str, str, dict) # target, text, file_path, msg_id, message_type, extra_data
    message_deleted = pyqtSignal(str) # msg_id
    server_lost = pyqtSignal()
    login_response = pyqtSignal(bool, str, dict) # success, message, user_data
    register_response = pyqtSignal(bool, str) # success, message
    receipt_received = pyqtSignal(str, str) # msg_id, status (server_received, peer_received, seen)
    history_received = pyqtSignal(str, list) # target, messages
    group_list_updated = pyqtSignal(list) # List of groups
    message_edited = pyqtSignal(str, str) # msg_id, new_content
    
    def __init__(self, user_data=None):
        super().__init__()
        self.user_data = user_data
        self.server_ip = None
        self.server_port = 50005
        self.udp_port = 50006
        self.sock = None
        self.running = False
        
    def start_discovery(self, callback):
        """Sunucuyu bulmak için UDP dinler"""
        threading.Thread(target=self._discovery_loop, args=(callback,), daemon=True).start()

    def _discovery_loop(self, callback):
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        udp_sock.bind(('', self.udp_port))
        
        print("[CLIENT] Sunucu aranıyor...")
        while not self.server_ip:
            try:
                data, addr = udp_sock.recvfrom(1024)
                print(f"[CLIENT] Paket alındı: {addr} -> {data}")
                packet = json.loads(data.decode('utf-8'))
                if packet.get("type") == "server_discovery":
                    self.server_ip = addr[0]
                    self.server_port = packet.get("port", 50005)
                    print(f"[CLIENT] Sunucu bulundu: {self.server_ip}")
                    callback(self.server_ip)
                    break
            except:
                time.sleep(1)
        udp_sock.close()

    def connect_to_server(self, ip):
        self.server_ip = ip
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(5.0) # 5 saniye bağlanma sınırı
            self.sock.connect((self.server_ip, self.server_port))
            self.sock.settimeout(None) # Dinleme için tekrar blokla
            self.running = True
            threading.Thread(target=self._receive_loop, daemon=True).start()
            return True
        except Exception as e:
            print(f"[CLIENT] Sunucuya bağlanılamadı: {e}")
            return False

    def login(self, username, password_hash):
        if not self.sock: return False
        packet = {
            "action": "LOGIN",
            "payload": {"username": username, "password_hash": password_hash}
        }
        self.sock.sendall(json.dumps(packet).encode('utf-8'))
        # Yanıt bekleme (Basitlik için senkron bekleyelim veya sinyalle dönelim)
        # Not: _receive_loop bunu yakalayacak. UI tarafında login_successful sinyali LANService üzerinden de yönetilebilir.

    def update_avatar(self, new_avatar):
        if not self.sock: return
        packet = {
            "action": "UPDATE_AVATAR",
            "payload": {"avatar": new_avatar}
        }
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def block_user(self, blocked_username):
        if not self.sock: return
        packet = {"action": "BLOCK_USER", "payload": {"blocked_username": blocked_username}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def delete_message(self, msg_id, target):
        if not self.sock: return
        packet = {"action": "DELETE_MSG", "payload": {"msg_id": msg_id, "target": target}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def get_history(self, target):
        if not self.sock: return
        packet = {"action": "GET_HISTORY", "payload": {"target": target}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def edit_message(self, msg_id, target, new_content):
        if not self.sock: return
        packet = {"action": "EDIT_MSG", "payload": {"msg_id": msg_id, "target": target, "content": new_content}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def create_group(self, group_name, members):
        if not self.sock: return
        packet = {
            "action": "CREATE_GROUP",
            "payload": {
                "group": {"group_name": group_name},
                "members": members
            }
        }
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def delete_group(self, group_id):
        if not self.sock: return
        packet = {"action": "DELETE_GROUP", "payload": {"group_id": group_id}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def add_group_member(self, group_id, username):
        if not self.sock: return
        packet = {"action": "ADD_GROUP_MEMBER", "payload": {"group_id": group_id, "username": username}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def remove_group_member(self, group_id, username):
        if not self.sock: return
        packet = {"action": "REMOVE_GROUP_MEMBER", "payload": {"group_id": group_id, "username": username}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def make_group_admin(self, group_id, username):
        if not self.sock: return
        packet = {"action": "MAKE_ADMIN", "payload": {"group_id": group_id, "username": username}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def send_receipt(self, target_username, msg_id, status):
        if not self.sock: return
        packet = {
            "action": "RECEIPT",
            "payload": {"msg_id": msg_id, "status": status, "target": target_username}
        }
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def send_message(self, target_username, text, file_path="", msg_id=None, message_type="TEXT", extra_data=None):
        if not self.sock: return
        import os, base64
        packet = {
            "action": "SEND_MSG",
            "payload": {
                "target_ip": target_username,
                "content": text,
                "msg_id": msg_id or str(time.time()),
                "message_type": message_type,
                "reply_to_id": extra_data.get("reply_to_id") if isinstance(extra_data, dict) else None,
                "is_forwarded": extra_data.get("is_forwarded", 0) if isinstance(extra_data, dict) else 0
            }
        }
        
        # Eğer target_username group_ ile başlıyorsa group_id set et
        if target_username and target_username.startswith("group_"):
            packet["payload"]["group_id"] = int(target_username.split("_")[1])
            packet["payload"]["target_ip"] = None
        
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, "rb") as f:
                    file_data = f.read()
                packet["payload"]["file_data"] = base64.b64encode(file_data).decode('utf-8')
                packet["payload"]["file_name"] = os.path.basename(file_path)
            except Exception as e:
                print(f"[CLIENT] Dosya okuma hatası: {e}")

        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def unblock_user(self, username):
        if not self.sock: return
        packet = {"action": "UNBLOCK_USER", "payload": {"blocked_username": username}}
        self.sock.sendall(json.dumps(packet).encode('utf-8'))

    def _receive_loop(self):
        import codecs
        decoder = codecs.getincrementaldecoder('utf-8')(errors='ignore')
        buffer = ""
        while self.running:
            try:
                raw_data = self.sock.recv(65536)
                if not raw_data: break
                
                buffer += decoder.decode(raw_data)
                while True:
                    buffer = buffer.lstrip()
                    if not buffer: break
                    try:
                        packet, index = json.JSONDecoder().raw_decode(buffer)
                        buffer = buffer[index:].lstrip()
                        self._handle_packet(packet)
                    except json.JSONDecodeError:
                        break
                    except Exception as e:
                        print(f"[CLIENT] Paket işleme hatası: {e}")
                        break
            except:
                break
        
        self.running = False
        self.server_lost.emit()

    def _handle_packet(self, packet):
        action = packet.get("action")
        payload = packet.get("payload")

        if action == "USER_LIST_UPDATE":
            # İstemciye tüm kullanıcı bilgilerini (online/offline, lastseen) ilet
            for user_info in payload:
                username = user_info.get("username")
                if self.user_data and username == self.user_data.get('username'): continue
                
                self.peer_found.emit({
                    "username": username,
                    "first_name": username,
                    "ip": username,
                    "avatar": user_info.get("avatar", "👤"),
                    "is_online": user_info.get("is_online"),
                    "lastseen": user_info.get("lastseen")
                })

        elif action == "RESPONSE":
            status = payload.get("status")
            message = payload.get("message")
            data = payload.get("data")
            if "Giriş" in message:
                self.login_response.emit(status == "SUCCESS", message, data or {})
            else:
                self.register_response.emit(status == "SUCCESS", message)

        elif action == "RECEIVE_MSG":
            sender = payload.get("sender")
            content = payload.get("content")
            msg_id = payload.get("msg_id")
            message_type = payload.get("message_type", "TEXT")
            file_name = payload.get("file_name")
            file_data = payload.get("file_data")
            save_path = ""
            
            if file_data:
                import base64, os
                download_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "resources", "downloads")
                os.makedirs(download_dir, exist_ok=True)
                save_path = os.path.join(download_dir, file_name)
                try:
                    with open(save_path, "wb") as f:
                        f.write(base64.b64decode(file_data))
                    print(f"[CLIENT] Dosya kaydedildi: {save_path}")
                except Exception as e:
                    print(f"[CLIENT] Dosya kaydetme hatası: {e}")
            
            # Target determines where the message will be displayed in the UI
            target = f"group_{payload.get('group_id')}" if payload.get('group_id') else sender
            
            extra_data = {
                "reply_to_id": payload.get("reply_to_id"),
                "is_forwarded": payload.get("is_forwarded"),
                "is_edited": payload.get("is_edited"),
                "sender": sender
            }
            
            self.message_received.emit(target, content, save_path, msg_id, message_type, extra_data)
            
            # Alındı onayı gönder (2 Tik için)
            ack = {
                "action": "RECEIPT",
                "payload": {"msg_id": msg_id, "status": "peer_received", "target": sender}
            }
            self.sock.sendall(json.dumps(ack).encode('utf-8'))

        elif action == "RECEIPT":
            self.receipt_received.emit(payload.get("msg_id"), payload.get("status"))
        elif action == "DELETE_MSG":
            self.message_deleted.emit(payload.get("msg_id"))
        elif action == "EDIT_MSG":
            self.message_edited.emit(payload.get("msg_id"), payload.get("content"))
        elif action == "GROUP_LIST_UPDATE":
            self.group_list_updated.emit(payload)

        elif action == "HISTORY_RES":
            target = payload.get("target")
            messages = payload.get("messages", [])
            self.history_received.emit(target, messages)

        elif action == "SHUTDOWN":
            print("[CLIENT] Sunucu kapandı!")
            self.running = False
            self.server_lost.emit()

    def stop(self):
        self.running = False
        if self.sock:
            try: self.sock.close()
            except: pass
