from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLineEdit, 
                             QListWidget, QListWidgetItem, QPushButton, QLabel, QMessageBox, QCheckBox, QMenu)
from PyQt6.QtCore import Qt

class GroupDialog(QDialog):
    def __init__(self, all_users, current_user, group_info=None, parent=None, lan_service=None):
        super().__init__(parent)
        self.all_users = all_users # List of usernames
        self.current_user = current_user
        self.group_info = group_info # If editing existing group
        self.lan_service = lan_service
        self.selected_users = []
        
        self.setWindowTitle("Grup Olustur" if not group_info else f"Grup: {group_info['group_name']}")
        self.setMinimumWidth(350)
        self.setStyleSheet("""
            QDialog { background-color: #202C33; color: white; } 
            QLabel { color: #E9EDEF; } 
            QLineEdit { background-color: #2A3942; color: white; border-radius: 5px; padding: 8px; border: 1px solid #3B4A54; } 
            QListWidget { background-color: #111B21; color: white; border: none; border-radius: 5px; padding: 5px; } 
            QPushButton { background-color: #00A884; color: white; border-radius: 5px; padding: 8px; font-weight: bold; border: none; }
            QPushButton:hover { background-color: #008F72; }
            QPushButton#DeleteBtn { background-color: #EA0038; }
            QPushButton#DeleteBtn:hover { background-color: #C30030; }
        """)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        
        # Grup Adi
        name_layout = QVBoxLayout()
        name_layout.addWidget(QLabel("Grup Adi:"))
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Grup adini girin...")
        name_layout.addWidget(self.name_input) # <--- Missing line fixed
        if group_info:
            self.name_input.setText(group_info['group_name'])
            i_am_admin = any(m['username'] == current_user and m['is_admin'] for m in group_info['members'])
            if not i_am_admin:
                self.name_input.setReadOnly(True)
        layout.addLayout(name_layout)
        
        # Uyeler Listesi
        list_label = QLabel("Uyeler Secin:" if not group_info else "Grup Uyeleri ve Kisiler:")
        layout.addWidget(list_label)
        
        self.user_list = QListWidget()
        self.refresh_user_list()
        layout.addWidget(self.user_list)

        if group_info:
            self.user_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            self.user_list.customContextMenuRequested.connect(self.show_member_context_menu)
            
            i_am_admin = any(m['username'] == current_user and m['is_admin'] for m in group_info['members'])
            if i_am_admin:
                self.btn_delete = QPushButton("🗑 Grubu Sil")
                self.btn_delete.setObjectName("DeleteBtn")
                self.btn_delete.clicked.connect(self.on_delete_group)
                layout.addWidget(self.btn_delete)
        
        self.btn_save = QPushButton("Olustur" if not group_info else "Kapat")
        self.btn_save.clicked.connect(self.on_save)
        layout.addWidget(self.btn_save)

    def refresh_user_list(self):
        self.user_list.clear()
        if self.group_info:
            member_names = [m['username'] for m in self.group_info['members']]
            for m in self.group_info['members']:
                role = " (Yonetici)" if m['is_admin'] else " (Uye)"
                display_name = f"👤 {m['username']}{role}"
                if m['username'] == self.current_user: display_name += " [Siz]"
                item = QListWidgetItem(display_name)
                item.setData(Qt.ItemDataRole.UserRole, m['username'])
                item.setForeground(Qt.GlobalColor.white)
                if m['is_admin']:
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                    from PyQt6.QtGui import QColor
                    item.setForeground(QColor("#00A884"))
                self.user_list.addItem(item)
            for user in self.all_users:
                if user not in member_names and user != self.current_user:
                    item = QListWidgetItem(f"➕ {user}")
                    item.setData(Qt.ItemDataRole.UserRole, user)
                    item.setForeground(Qt.GlobalColor.gray)
                    self.user_list.addItem(item)
        else:
            for user in self.all_users:
                if user == self.current_user: continue
                item = QListWidgetItem(user)
                item.setData(Qt.ItemDataRole.UserRole, user)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Unchecked)
                self.user_list.addItem(item)

    def on_save(self):
        if not self.group_info:
            self.selected_users = []
            for i in range(self.user_list.count()):
                item = self.user_list.item(i)
                if item.checkState() == Qt.CheckState.Checked:
                    self.selected_users.append(item.data(Qt.ItemDataRole.UserRole))
            if not self.name_input.text().strip():
                QMessageBox.warning(self, "Hata", "Lutfen bir grup adi girin.")
                return
            if not self.selected_users:
                QMessageBox.warning(self, "Hata", "Lutfen en az bir uye secin.")
                return
            self.accept()
        else:
            self.close()

    def show_member_context_menu(self, pos):
        item = self.user_list.itemAt(pos)
        if not item: return
        username = item.data(Qt.ItemDataRole.UserRole)
        am_i_admin = any(m['username'] == self.current_user and m['is_admin'] for m in self.group_info['members'])
        if not am_i_admin or username == self.current_user: return
        member_info = next((m for m in self.group_info['members'] if m['username'] == username), None)
        is_member = member_info is not None
        is_target_admin = member_info['is_admin'] if is_member else False
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #202C33; color: white; border: 1px solid #2A3942; } QMenu::item:selected { background-color: #374248; }")
        if is_member:
            action_make_admin = menu.addAction("⭐ Yonetici Yap")
            action_make_admin.setEnabled(not is_target_admin)
            action_remove = menu.addAction("❌ Gruptan Cikar")
            action_add = None
        else:
            action_make_admin = None
            action_remove = None
            action_add = menu.addAction("➕ Gruba Ekle")
        action = menu.exec(self.user_list.mapToGlobal(pos))
        if action_make_admin and action == action_make_admin:
            if self.lan_service:
                self.lan_service.make_group_admin(self.group_info['group_id'], username)
                self.close()
        elif action_remove and action == action_remove:
            if self.lan_service:
                self.lan_service.remove_group_member(self.group_info['group_id'], username)
                self.close()
        elif action_add and action == action_add:
            if self.lan_service:
                self.lan_service.add_group_member(self.group_info['group_id'], username)
                self.close()

    def on_delete_group(self):
        reply = QMessageBox.question(self, "Grubu Sil", "Bu grubu tamamen silmek istediginize emin misiniz?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            if self.lan_service:
                self.lan_service.delete_group(self.group_info['group_id'])
                self.accept()

    def get_data(self):
        return {"group_name": self.name_input.text().strip(), "members": self.selected_users}
