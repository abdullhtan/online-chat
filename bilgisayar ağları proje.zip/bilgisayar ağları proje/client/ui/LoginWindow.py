from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QTabWidget, QWidget, QMessageBox)
from PyQt6.QtCore import Qt, pyqtSignal
import hashlib

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

class LoginWindow(QDialog):
    login_successful = pyqtSignal(dict)

    def __init__(self, lan_service):
        super().__init__()
        self.lan_service = lan_service
        self.setWindowTitle("LAN Sohbet - Giriş")
        self.setFixedSize(350, 400)
        self.setObjectName("MainBackground")
        
        # Sinyalleri bağla
        self.lan_service.login_response.connect(self.on_login_response)
        self.lan_service.register_response.connect(self.on_register_response)
        
        main_layout = QVBoxLayout(self)
        
        title_lbl = QLabel("💬 LAN Sohbet")
        title_lbl.setStyleSheet("font-size: 24px; font-weight: bold; color: #00A884;")
        title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title_lbl)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { border: none; }
            QTabBar::tab { background: #202C33; padding: 10px 30px; font-weight: bold; }
            QTabBar::tab:selected { background: #2A3942; border-bottom: 2px solid #00A884; }
        """)
        
        self.tab_login = QWidget()
        self.tab_register = QWidget()
        self.tabs.addTab(self.tab_login, "Giriş Yap")
        self.tabs.addTab(self.tab_register, "Kayıt Ol")
        
        self.setup_login_tab()
        self.setup_register_tab()
        main_layout.addWidget(self.tabs)

    def setup_login_tab(self):
        layout = QVBoxLayout(self.tab_login)
        layout.addStretch()
        
        self.log_user = QLineEdit()
        self.log_user.setPlaceholderText("Kullanıcı Adı")
        self.log_user.setObjectName("SearchBar")
        layout.addWidget(self.log_user)
        
        self.log_pass = QLineEdit()
        self.log_pass.setPlaceholderText("Şifre")
        self.log_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.log_pass.setObjectName("SearchBar")
        layout.addWidget(self.log_pass)
        
        self.btn_login = QPushButton("Giriş Yap")
        self.btn_login.setStyleSheet("background-color: #00A884; border-radius: 8px; padding: 10px; font-weight: bold;")
        self.btn_login.clicked.connect(self.do_login)
        layout.addWidget(self.btn_login)
        layout.addStretch()

    def setup_register_tab(self):
        layout = QVBoxLayout(self.tab_register)
        layout.addStretch()
        
        self.reg_user = QLineEdit()
        self.reg_user.setPlaceholderText("Kullanıcı Adı")
        self.reg_user.setObjectName("SearchBar")
        layout.addWidget(self.reg_user)
        
        self.reg_pass = QLineEdit()
        self.reg_pass.setPlaceholderText("Şifre")
        self.reg_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.reg_pass.setObjectName("SearchBar")
        layout.addWidget(self.reg_pass)
        
        self.btn_reg = QPushButton("Kayıt Ol")
        self.btn_reg.setStyleSheet("background-color: #2A3942; border-radius: 8px; padding: 10px; font-weight: bold;")
        self.btn_reg.clicked.connect(self.do_register)
        layout.addWidget(self.btn_reg)
        layout.addStretch()

    def do_login(self):
        u = self.log_user.text().strip()
        p = self.log_pass.text()
        if not u or not p: return
        
        self.btn_login.setEnabled(False)
        self.btn_login.setText("Giriş Yapılıyor...")
        self.lan_service.login(u, hash_password(p))

    def on_login_response(self, success, message, data):
        self.btn_login.setEnabled(True)
        self.btn_login.setText("Giriş Yap")
        if success:
            # Server username dönerse first_name olarak da onu kullanalım
            user_data = {
                "username": data.get("username", self.log_user.text()),
                "first_name": data.get("username", self.log_user.text()),
                "last_name": "",
                "password": self.log_pass.text()
            }
            self.login_successful.emit(user_data)
            self.accept()
        else:
            QMessageBox.warning(self, "Hata", message)

    def do_register(self):
        u = self.reg_user.text().strip()
        p = self.reg_pass.text()
        if not u or not p: return
        
        self.btn_reg.setEnabled(False)
        # Register paketi elle oluşturulur çünkü LANService'da henüz metodu yok (ekleyeceğiz)
        packet = {
            "action": "REGISTER",
            "payload": {"username": u, "passwordhash": hash_password(p)}
        }
        self.lan_service.sock.sendall(import_json().dumps(packet).encode('utf-8'))

    def on_register_response(self, success, message):
        self.btn_reg.setEnabled(True)
        if success:
            QMessageBox.information(self, "Başarılı", "Kayıt başarılı! Giriş yapabilirsiniz.")
            self.tabs.setCurrentIndex(0)
        else:
            QMessageBox.warning(self, "Hata", message)

def import_json():
    import json
    return json
