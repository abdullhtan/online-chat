import sys
import os
import time

# Ana dizini sys.path'e eklerek common ve server modüllerine erişim sağlayalım
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from PyQt6.QtWidgets import QApplication, QMessageBox, QLineEdit, QInputDialog
from PyQt6.QtCore import Qt
from ui.RoleSelectionWindow import RoleSelectionWindow
from ui.LoginWindow import LoginWindow
from ui.MainWindow import MainWindow
from services.LANService import LANService
from server.SocketServer import SocketServer

def load_stylesheet(app_instance):
    style_path = os.path.join(os.path.dirname(__file__), "resources", "StyleSheet.qss")
    if os.path.exists(style_path):
        with open(style_path, "r", encoding="utf-8") as f:
            app_instance.setStyleSheet(f.read())

def main():
    app = QApplication(sys.argv)
    load_stylesheet(app)

    # 1. Rol Seçimi
    role_window = RoleSelectionWindow()
    if role_window.exec() == 0:
        sys.exit(0)
    
    selected_role = role_window.role
    server_instance = None
    lan_service = LANService()

    if selected_role == 'server':
        server_instance = SocketServer()
        if not server_instance.start():
            QMessageBox.critical(None, "Hata", "Sunucu başlatılamadı! Başka bir sunucu zaten çalışıyor olabilir.")
            sys.exit(1)
        # Sunucu kendi kendine bağlanır
        lan_service.connect_to_server("127.0.0.1")
    else:
        # İstemci ise sunucuyu bul
        from PyQt6.QtCore import QEventLoop, QTimer
        loop = QEventLoop()
        found_ip = []
        
        def on_server_found(ip):
            found_ip.append(ip)
            loop.quit()
            
        lan_service.start_discovery(on_server_found)
        # 10 saniye sonra loop'u kapat
        QTimer.singleShot(10000, loop.quit)
        loop.exec()
        
        if not found_ip:
            # Manuel IP Girişi Fallback
            ip, ok = QInputDialog.getText(None, "Sunucu Bulunamadı", "Sunucu otomatik bulunamadı.\nLütfen Sunucu IP adresini girin:", QLineEdit.EchoMode.Normal, "127.0.0.1")
            if ok and ip:
                if not lan_service.connect_to_server(ip):
                    QMessageBox.critical(None, "Hata", f"Sunucuya ({ip}) bağlanılamadı!")
                    sys.exit(1)
            else:
                sys.exit(0)
        else:
            lan_service.connect_to_server(found_ip[0])

    # 2. Giriş Ekranı
    login_screen = LoginWindow(lan_service)
    current_user_data = None
    
    def on_login_success(user_dict):
        nonlocal current_user_data
        current_user_data = user_dict
        lan_service.user_data = user_dict
        
    login_screen.login_successful.connect(on_login_success)
    
    if login_screen.exec() == 0 or current_user_data is None:
        if server_instance: server_instance.stop()
        sys.exit(0)
    
    # 3. Ana Pencere
    window = MainWindow(current_user_data)
    
    # Kendine mesaj atabilmek için sidebar'a "Sen" ekle
    window.sidebar.add_lan_contact("Sen", current_user_data['username'], current_user_data.get('avatar', "👤"))

    # Sinyalleri Bağla
    def on_peer_found(peer_info):
        username = peer_info.get("username")
        # Eğer bu bizsek (başka pc'den aynı hesapla girdiysek veya listede varsak) "Siz" olarak kalsın
        if username == current_user_data['username']: return
        
        window.sidebar.add_lan_contact(
            peer_info.get("first_name", "İsimsiz"), 
            username, 
            peer_info.get("avatar", "👤"),
            is_online=peer_info.get("is_online", True),
            lastseen=peer_info.get("lastseen")
        )
        
        # Eğer şu an bu kişiyle konuşuyorsak, tepedeki barı da güncelle
        if window.chat_view._current_chat_ip == username:
            status = "çevrimiçi" if peer_info.get("is_online") else f"son görülme: {peer_info.get('lastseen')}"
            window.chat_view.chat_status.setText(status)
    
    lan_service.peer_found.connect(on_peer_found)
    
    window.sidebar.profile_clicked.disconnect() # MainWindow'daki default bağlantıyı kopar (eğer varsa)
    window.sidebar.profile_clicked.connect(lambda: window.open_profile_settings(lan_service))
    
    # Bloklama İsteği
    def on_block_requested(username):
        reply = QMessageBox.question(window, "Kullanıcıyı Engelle", f"{username} kullanıcısını engellemek istediğinize emin misiniz?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            lan_service.block_user(username)
            QMessageBox.information(window, "Başarılı", f"{username} engellendi.")
    
    window.sidebar.block_requested.connect(on_block_requested)
    window.chat_view.block_requested.connect(on_block_requested)

    # Grup İşlemleri
    def on_create_group():
        all_users = []
        for i in range(window.sidebar.contact_list.count()):
            data = window.sidebar.contact_list.item(i).data(Qt.ItemDataRole.UserRole)
            if data and not data[2].startswith("group_") and data[2] != "Sen":
                all_users.append(data[2])
        
        from ui.GroupDialog import GroupDialog
        dialog = GroupDialog(all_users, current_user_data['username'], lan_service=lan_service)
        if dialog.exec():
            data = dialog.get_data()
            lan_service.create_group(data['group_name'], data['members'])

    window.sidebar.create_group_requested.connect(on_create_group)

    # Grup Listesi Güncelleme
    window.current_groups = {} # {group_id: group_dict}
    def on_groups_updated(groups):
        window.current_groups = {g['group_id']: g for g in groups}
        window.sidebar.update_groups(groups)
        
        # Eğer aktif sohbet bir grupsa ve güncellendiyse başlığı güncelle
        curr = window.chat_view._current_chat_ip
        if curr and curr.startswith("group_"):
            gid = int(curr.split("_")[1])
            if gid in window.current_groups:
                g_info = window.current_groups[gid]
                window.chat_view.chat_status.setText(f"{len(g_info['members'])} üye, {sum(1 for m in g_info['members'] if m.get('is_online'))} çevrimiçi")
            else:
                # Grup silinmiş veya çıkarılmışız
                window.chat_view.clear_chat()
                window.chat_view.set_chat_target(None, "Sohbet seçin")

    lan_service.group_list_updated.connect(on_groups_updated)

    # Mesaj Düzenleme (UI -> Servis)
    def on_ui_message_edit(msg_id, new_content, target):
        lan_service.edit_message(msg_id, target, new_content)

    window.chat_view.message_edited.connect(on_ui_message_edit)

    # Mesaj Düzenleme (Servis -> UI)
    def on_remote_message_edited(msg_id, content):
        if msg_id in window.chat_view.bubbles:
            window.chat_view.bubbles[msg_id].update_text(content)

    lan_service.message_edited.connect(on_remote_message_edited)

    # Mesaj İletme (Forward)
    def on_forward_requested(msg_id, source_target):
        # Mesajı bul
        if msg_id not in window.chat_view.last_msgs_map: return
        _, text = window.chat_view.last_msgs_map[msg_id]
        
        # Hedef seç
        all_contacts = []
        for i in range(window.sidebar.contact_list.count()):
            data = window.sidebar.contact_list.item(i).data(Qt.ItemDataRole.UserRole)
            if data: all_contacts.append(data)
            
        from PyQt6.QtWidgets import QDialog, QListWidget, QVBoxLayout, QPushButton
        f_dialog = QDialog(window)
        f_dialog.setWindowTitle("Mesajı İlet")
        f_layout = QVBoxLayout(f_dialog)
        list_w = QListWidget()
        for c in all_contacts:
            if c[2] == "Sen": continue
            list_w.addItem(f"{c[0]} ({c[2]})")
        f_layout.addWidget(list_w)
        btn_f = QPushButton("İlet")
        f_layout.addWidget(btn_f)
        
        def do_forward():
            sel = list_w.currentRow()
            if sel >= 0:
                target_data = all_contacts[sel]
                target_id = target_data[2]
                new_msg_id = str(time.time())
                extra = {"is_forwarded": 1}
                lan_service.send_message(target_id, text, "", new_msg_id, "TEXT", extra)
                QMessageBox.information(window, "Başarılı", f"Mesaj {target_data[0]} kişisine iletildi.")
                f_dialog.accept()

        btn_f.clicked.connect(do_forward)
        f_dialog.exec()

    window.chat_view.forward_requested.connect(on_forward_requested)

    # Mesaj Silme İsteği (Arayüzden tetiklenen)
    def on_ui_message_delete(msg_id, target):
        lan_service.delete_message(msg_id, target)
        window.chat_view.remove_single_message(msg_id)

    window.chat_view.message_deleted.connect(on_ui_message_delete)

    # Mesaj Silme Bilgisi (Sunucudan gelen)
    def on_remote_message_deleted(msg_id):
        window.chat_view.remove_single_message(msg_id)

    lan_service.message_deleted.connect(on_remote_message_deleted)

    def on_message_received(target, text, file_path, msg_id, message_type, extra_data):
        # Eğer bu mesajı zaten biz gönderdiysek tekrar ekleme
        if msg_id in window.chat_view.bubbles:
            return
            
        import winsound
        try: winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS | winsound.SND_ASYNC)
        except: pass
        
        # Sadece aktif sohbete aitse ekle
        if window.chat_view._current_chat_ip == target:
            window.chat_view.add_message(text, is_sender=False, file_path=file_path, msg_id=msg_id, sender_username=target, message_type=message_type, extra_data=extra_data)
        else:
            # Aktif sohbet değilse sidebar'da bildirim veya başka bir işlem yapılabilir
            print(f"[CLIENT] Aktif olmayan sohbetten mesaj: {target} -> {text}")

    lan_service.message_received.connect(on_message_received)
    lan_service.receipt_received.connect(window.chat_view.update_message_status)
    lan_service.server_lost.connect(lambda: (QMessageBox.warning(window, "Bağlantı Kesildi", "Sunucu kapandı!"), window.close()))

    def on_history_received(target, messages):
        if window.chat_view._current_chat_ip == target:
            for msg in messages:
                is_me = msg['sender'] == current_user_data['username']
                # Mesajları tek tek ekle
                window.chat_view.add_message(
                    text=msg['content'],
                    is_sender=is_me,
                    file_path=msg.get('file_path'),
                    msg_id=msg.get('msg_id'),
                    sender_username=msg['sender'],
                    message_type=msg.get('message_type', 'TEXT'),
                    extra_data={
                        "reply_to_id": msg.get("reply_to_id"),
                        "is_forwarded": msg.get("is_forwarded"),
                        "is_edited": msg.get("is_edited")
                    }
                )

    lan_service.history_received.connect(on_history_received)
    window.chat_view.history_requested.connect(lan_service.get_history)

    def on_user_sent_message(text, target_username, file_path="", msg_id=None, message_type="TEXT", extra_data=None):
        if text == "[SEEN]":
            lan_service.send_receipt(target_username, msg_id, "seen")
        else:
            lan_service.send_message(target_username, text, file_path, msg_id, message_type, extra_data)

    window.chat_view.message_sent.connect(on_user_sent_message)

    # Kapanışta temizlik
    def cleanup():
        lan_service.stop()
        if server_instance: server_instance.stop()

    app.aboutToQuit.connect(cleanup)
    
    # Sidebar öğe tıklandığında (Grup yönetimi için ekstra)
    def on_sidebar_item_clicked(name, avatar, target_id):
        if target_id.startswith("group_"):
            # Sağ üstteki ⋮ butonunu grup yönetimi için kullanabiliriz veya Sidebar'a sağ tık ekleyebiliriz
            # Şimdilik SidebarWidget'a grup için sağ tık ekleyelim (SidebarWidget.py'de zaten var)
            pass

    window.sidebar.contact_selected.connect(on_sidebar_item_clicked)
    
    def on_group_settings_requested(gid):
        group_info = window.current_groups.get(gid)
        if group_info:
            from ui.GroupDialog import GroupDialog
            all_users = [window.sidebar.contact_list.item(i).data(Qt.ItemDataRole.UserRole)[2] for i in range(window.sidebar.contact_list.count()) if not window.sidebar.contact_list.item(i).data(Qt.ItemDataRole.UserRole)[2].startswith("group_")]
            dialog = GroupDialog(all_users, current_user_data['username'], group_info=group_info, lan_service=lan_service)
            dialog.exec()

    window.chat_view.group_settings_requested.connect(on_group_settings_requested)
    
    # Sidebar sağ tık menüsü
    def on_sidebar_context_menu(pos):
        item = window.sidebar.contact_list.itemAt(pos)
        if not item: return
        data = item.data(Qt.ItemDataRole.UserRole)
        if not data: return
        
        target_id = data[2]
        from PyQt6.QtWidgets import QMenu
        menu = QMenu(window)
        
        if target_id.startswith("group_"):
            action_clear = menu.addAction("🗑️ Sohbeti Temizle")
            action_manage = menu.addAction("👥 Grup Ayarları")
            action = menu.exec(window.sidebar.contact_list.mapToGlobal(pos))
            
            if action == action_clear:
                window.chat_view.clear_chat()
            elif action == action_manage:
                on_group_settings_requested(int(target_id.split("_")[1]))
        else:
            action_clear = menu.addAction("🗑️ Sohbeti Temizle")
            action_block = menu.addAction("🚫 Engelle")
            action = menu.exec(window.sidebar.contact_list.mapToGlobal(pos))
            
            if action == action_clear:
                window.chat_view.clear_chat()
            elif action == action_block:
                lan_service.block_user(target_id)

    window.sidebar.contact_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
    window.sidebar.contact_list.customContextMenuRequested.connect(on_sidebar_context_menu)

    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
